<!DOCTYPE html>
<html>
<body>

<?php
echo "This is vinod's new web site VERSION 66666";
?>

</body>
</html>
