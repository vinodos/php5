<!DOCTYPE html>
<html>
<body>

<?php
echo "Vinod test web site ";
?>

</body>
</html>